%{
msh-MOLED parallel reconstruction
qzyang Aug 2022
%}
ccc;
% filepath = 'F:\2022Aug_浙大数据\220806_knee\';
% dataname = 'meas_MID00823_FID35861_ep_seg_se_oled_512.dat';

% pathfile = 'E:\BaiduNetdiskDownload\20230525_yqz\subject2';
% dataname = 'meas_MID02345_FID1073883_ep_seg_se_oled_minTE.dat';
% pathsave = 'E:\BaiduNetdiskDownload\20230525_yqz\subject2\MID02338';

% pathfile = 'F:\2022Aug_浙大数据\20220813_phantom2_OK\';
% dataname = 'meas_MID00488_FID38356_ep_seg_se_moled_factor65.dat';
% pathsave = 'F:\2022Aug_浙大数据\20220813_phantom2_OK\MID00488';

% pathfile = 'E:\2023Dec_ZZH';
% dataname = 'meas_MID00782_FID1352279_ep_seg_se_oled_256.dat';
% pathsave = 'E:\2023Dec_ZZH\MID00782';

% pathfile = 'F:\workshop#2mshMOLED\240518_ptm';
% dataname = 'meas_MID04997_FID1839456_ep_seg_se_oled_rTE.dat';
% pathsave = 'F:\workshop#2mshMOLED\240518_ptm\MID04997';

% pathfile = 'F:\2022Aug_浙大数据\220809_gwh';
% dataname = 'meas_MID00462_FID36835_ep_seg_se_moled_256.dat';
% pathsave = 'F:\2022Aug_浙大数据\220809_gwh\MID00462';

pathfile = 'E:\231219_ZZH';
dataname = 'meas_MID01677_FID378692_ep_seg_se_oled_256.dat';
pathsave = 'F:\workshop#2mshMOLED\@MRM_reresub\cmp_acce_ssh';

flag_crg  = [];
flag_save = true;
snav      = 1; % 2 % if

id_recon  = 14;%1:21;
tot_slice = 21;

Necho     = 1; % single-train
% loading
[ksp, ... % [RO PE coil slice]
    ksp_PC, Nread, Nphase, Nslice, Ncoil, NETL, Nseg, FOVread, FOVphase] = mshMOLED_reader(fullfile(pathfile, dataname));

if ~le(Nslice, tot_slice)
    aa      = sprintf("Total slice number is %d!!!", Nslice);
    warndlg(char(aa));
end
%%
for id_slice = id_recon
    ksp_cor      = run_mshMOLED_recon_func(ksp(:,:,:,id_slice), ksp_PC(:,:,:,id_slice), Nread, Ncoil, NETL, Nseg, Necho, snav);
%     fig;imshow3(abs(ifft2c(ksp(:,:,:,id_slice))));
%     fig;imshow3(abs(ifft2c(complex_k2)));
    [maxt,maxid] = max(mean(ksp_cor,[1,2])); % self-navigator
    sen          = adaptive_sens_acs(ksp_cor, [FOVread/Nread, FOVphase/Nphase], maxid, 5, Nread, Nphase, Ncoil);
    complex_k2   = fft2c(adaptive_combination(ifft2c(ksp_cor),sen));
    if eq(flag_save, true)
        save(fullfile(pathsave, [dataname(6:14), 'Layer', num2str(1000+id_slice), '.mat']),'complex_k2');
        disp(['layer ', num2str(id_slice), ' saved.'])
    end
end
