function img_com=fun_ESPIRIT(ksp_multi,kacs)
[sx,sy,Nc] = size(ksp_multi);
ksize = [6,6]; % ESPIRiT kernel-window-size
eigThresh_k = 0.02; % threshold of eigenvectors in k-space
eigThresh_im = 0.9; % threshold of eigenvectors in image space
[k,S] = dat2Kernel(kacs,ksize);
idx = max(find(S >= S(1)*eigThresh_k));
[M,W] = kernelEig(k(:,:,:,1:idx),[sx,sy]);
maps = M(:,:,:,end-1:end);
weights = W(:,:,end-1:end);
nIterCG = 12;
ESP = ESPIRiT(maps,weights);
[reskESPIRiT, resESPIRiT] = cgESPIRiT(ksp_multi,ESP, nIterCG, 0.01,ksp_multi*0);
img_com=resESPIRiT(:,:,2);
end