function [kCalib,kappa1,phi1]=fun_EPIcorrect_GO(kCalib,echoi)
if mod(echoi,2)==1
    nav=1;
else
    nav=-1;
end

kraw1=permute(kCalib,[1,3,2]);
kCalib_correct=zeros(size(kraw1));

kappa1=zeros(size(kraw1,3),1);
phi1=zeros(size(kraw1,3),1);

for loopi = 1:size(kraw1,3)
    startOptSimplex.kCenter = nav*0.35;%0.29
    startOptSimplex.pCenter = 3;%3
    method = 'Gh/Ob';
    [kappa1(loopi), phi1(loopi)] = simplexSearch(kraw1(:,:,loopi), startOptSimplex, method);
    tempK = applyFirstOrderPhaseCorr( kraw1(:,:,loopi), kappa1(loopi), phi1(loopi));
    kCalib_correct(:,:,loopi) = tempK(:,1:end);
end
kCalib=permute(kCalib_correct,[1,3,2]);
end