fn='meas_MID00933_raw';

slice_begin=2;
slice_end=2;
m_begin=1;
m_end=1;

fn_ksp=[fn,'/ksp/'];fn_kpc=[fn,'/kpc/'];fn_kacs=[fn,'/kacs/'];

fn_dir=[fn,'/recon/'];

if ~exist(fn_dir,'dir')==1
    mkdir(fn_dir);
end

ksp_list=dir([fn_ksp,'*.mat']);
kpc_list=dir([fn_kpc,'*.mat']);
kacs_list=dir([fn_kacs,'*.mat']);

for iii=slice_begin:slice_end
    %%
    if iii<10
        output_slice_dir=[fn_dir,'layer_0',num2str(iii),'/'];
    else
        output_slice_dir=[fn_dir,'layer_',num2str(iii),'/'];
    end
    if ~exist(output_slice_dir,'dir')==1
        mkdir(output_slice_dir);
    end
    
    load([fn_ksp,ksp_list(iii).name]); % 128    58   126     1   240
    load([fn_kpc,kpc_list(iii).name]); % 128    58     3     1   240
    load([fn_kacs,kacs_list(iii).name]); % 128    58    24
    
    %% phase correction for ACS data
    kacs=fun_EPIcorrect_GO(kacs);
    kacs=permute(kacs,[1,3,2]);
    
    %% Parallel reconstruction for undersampled data
    for jjj=m_begin:m_end
        tic;
        temp_ksp=ksp(:,:,:,1,jjj);
        temp_pc=kpc(:,:,:,1,jjj);
        
        % phase correction for undersampled data
        temp_ksp(:,:,2:2:end)=EPIEvenoddFix(temp_ksp(:,:,2:2:end),temp_pc,1,3,-1);
        temp_ksp=permute(temp_ksp,[1,3,2]);
        
        % ESPIRIT reconstruction
        ksp_com= fun_ESPIRIT(double(temp_ksp),kacs);
        complex_k2=fft2c(ksp_com);
        
        if jjj<10
            tar_file = [output_slice_dir,'Brain_layer',num2str(iii),'_fra_00',num2str(jjj),'.mat'];
        elseif jjj<100
            tar_file = [output_slice_dir,'Brain_layer',num2str(iii),'_fra_0',num2str(jjj),'.mat'];
        else
            tar_file = [output_slice_dir,'Brain_layer',num2str(iii),'_fra_',num2str(jjj),'.mat'];
        end
        save(tar_file,'complex_k2');
        disp(['Slice ',num2str(iii),' frame ',num2str(jjj),' finished.']);toc;
    end
end
