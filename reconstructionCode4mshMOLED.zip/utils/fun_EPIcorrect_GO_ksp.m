function [ksp]=fun_EPIcorrect_GO_ksp(ksp,kappa1,phi1)
kraw1=permute(ksp,[1,3,2]);
kCalib_correct=zeros(size(kraw1));

for loopi = 1:size(kraw1,3)
    % for ksp
    tempK = applyFirstOrderPhaseCorr( kraw1, kappa1(loopi), phi1(loopi));
    kCalib_correct(:,:,loopi) = tempK(:,1:end);
end
ksp=permute(kCalib_correct,[1,3,2]);
end