function img_cmb=espirit_com(ksp_multi,kacs)
[sx,sy,Nc] = size(ksp_multi);
ksize = [6,6]; % ESPIRiT kernel-window-size
eigThresh_k = 0.01; % threshold of eigenvectors in k-space
[k,S] = dat2Kernel(kacs,ksize);
idx = max(find(S >= S(1)*eigThresh_k));
[M,W] = kernelEig(k(:,:,:,1:idx),[sx,sy]);
sen=M(:,:,:,end);

img_orig=ifft2c(ksp_multi);
sen = reshape(sen,[],Nc);
img = reshape(img_orig,[],Nc);
img_cmb = sum(conj(sen).*img,2)./sum(sen.*conj(sen),2);
img_cmb = reshape(img_cmb,[sx,sy]);
img_cmb(isnan(img_cmb)) = 0;
img_cmb(isinf(img_cmb)) = 0;

end