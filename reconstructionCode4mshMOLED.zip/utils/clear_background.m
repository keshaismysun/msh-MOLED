function [ destine_image ] = clear_background( source_image,min_num)   %  ȥ��ë���Ե
    matrix_size=size(source_image);
    destine_image=zeros(matrix_size);
    if nargin==1
        min_num=4;
    end
    for i=2:1:matrix_size(1)-1
        for j=2:1:matrix_size(2)-1
            if source_image(i,j) ~= 0
                pixels_number=0;
                for i2=-1:1:1
                    for j2=-1:1:1
                        new_i=i+i2;
                        new_j=j+j2;
                        if source_image(new_i,new_j) ~=0 
                            pixels_number=pixels_number+1;
                        end
                    end
                end
                if pixels_number >min_num
                    destine_image(i,j)=source_image(i,j);
                end
            end
        end
    end
end

