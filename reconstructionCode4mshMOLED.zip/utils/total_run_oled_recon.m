% Parallel reconstruction for OLED raw data using PEC-GRAPPA and GCC
% and Phase correction (Siemens)
%-------------------------------------------------------%
% ksp: Multi-coil unreconstructed kspace data
% kCalib: Multi-coil ACS data
% ksp_PC: Multi-coil Phase correction data
% reture:
% complex_k2: Combined reconstructed kspace data [Slice Freq Phase EchoTrain]
%-------------------------------------------------------%
%Modified on 2021/04/29, Qinqin Yang;
%-------------------------------------------------------%
%%
clc;clear;
datapath='/data1/YQQ_FOLD/hk/';

datname='meas_MID00933_FID927123_bjf_a_oled_four_pure_ge_bold.dat';

total_slices=25;  % brain--->21 phantom--->11
fram_num=240;

% slice
begin_slice=1;  %8
end_slice=1;

% motion frame
begin_m=1;
end_m=240;

outputdir='meas_MID00933';

if ~exist(outputdir,'dir')==1
    mkdir(outputdir);
end

%% para
DataFileFullPath = fullfile(datapath, '', datname) ;
options.save=0;
options.gcc.use=0;
snav=1;
options.gcc.pat=1;

slice_num=end_slice-begin_slice+1;
slice_order=zeros(1,slice_num);
center_slice=floor((total_slices+1)/2);

if mod(total_slices,2)==0
    for i=1:1:slice_num
        current_slice=begin_slice+i-1;   % true slice pos
        if mod(current_slice,2) ==1
            slice_order(i)=(current_slice+1)/2+center_slice;
        else
            slice_order(i) = current_slice/2;
        end
    end
else
    for i=1:1:slice_num
        current_slice=begin_slice+i-1;   % true slice pos
        if mod(current_slice,2) ==1
            slice_order(i)=(current_slice+1)/2;
        else
            slice_order(i)=(current_slice)/2+center_slice;
        end
    end
end

begin_mm=1;
for i=1:1:fram_num
    fram_order(i)=begin_mm;
    begin_mm=begin_mm+1;
end

%%  recon
twix_obj=mapVBVD(DataFileFullPath,'removeOS','ignoreSeg','rampSampRegrid');
if iscell(twix_obj)
    twix_obj=twix_obj{end};
end
recon_order=1;
%%
para_train_num=1;
gcc=0;
pec=0;

optionsDefault.gcc.use=1;
optionsDefault.gcc.ncc=12;
optionsDefault.gcc.slwin=15;
optionsDefault.save=0;

options= UpdateParams(optionsDefault, options);
ksp_ori=twix_obj.image();
ksp_ori=squeeze(twix_obj.image());

channel_num=size(ksp_ori,2);
echo_train_num=size(ksp_ori,5);
real_total_slice_num= size(ksp_ori,4);
phase_num=size(ksp_ori,3);
freq_num=size(ksp_ori,1);


if total_slices ~= real_total_slice_num
    aa=sprintf(string('Total slice number is %d  !!!'),real_total_slice_num);
    warndlg(char(aa)) ;
    return ;
end

%%
for iii=begin_slice:end_slice
    if iii<10
        output_slice_dir=[outputdir,'layer_0',num2str(iii),'\'];
    else
        output_slice_dir=[outputdir,'layer_',num2str(iii),'\'];
    end
    
    if ~exist(output_slice_dir,'dir')==1
        mkdir(output_slice_dir);
    end
    for jjj=begin_m:end_m
        total_orig_slice=total_slices;
        slice_id=slice_order(recon_order);
        fram_id=fram_order(jjj);
        %%
        begin_slice=slice_id;
        end_slice=slice_id;
        slice_num=end_slice-begin_slice+1;
        ksp=ksp_ori(:,:,:,begin_slice:end_slice,fram_id);
        
        sqzSize=twix_obj.image.sqzSize;
        sqzSize(3)=3;
        sqzDims0=twix_obj.image.sqzDims;
        IndexCell=cell(size(sqzSize));
        optionsLogical=isfield(options,sqzDims0);
        for m=1:length(sqzSize)
            if optionsLogical(m)
                IndexCell{m}=getfield(options,sqzDims0{m});
            else
                IndexCell{m}=':';
            end
        end
        ksp=ksp(IndexCell{:});
        disp('Raw data loaded!');
        
        %%
        % load phase correction data
        if (isfield(twix_obj,'phasecor'))
            ksp_PC0=squeeze(twix_obj.phasecor.unsorted());
            Neco=twix_obj.image.NEco;
            Nave=twix_obj.image.NAve;
            sPC0=size(ksp_PC0);
            if (Nave>1&&Neco>1)
                ksp_PC0=reshape(ksp_PC0,[sPC0(1) sPC0(2) sPC0(3)/Nave Nave]);
                ksp_PC=zeros(sqzSize);
                for neco=1:Neco
                    ksp_PC(:,:,:,:,neco)=(ksp_PC0);
                end
                ksp_PC=single(ksp_PC);
            else if (Neco>0)
                    ksp_PC=zeros(sqzSize);
                    ksp_PC0=reshape(ksp_PC0,[sqzSize(1),sqzSize(2),sqzSize(3),sqzSize(4),sqzSize(5)]);
                    ksp_PC=(ksp_PC0);
                    ksp_PC=single(ksp_PC);
                    
                    %%%%%% ccb
                    ksp_PC=ksp_PC(:,:,:,begin_slice:end_slice,fram_id);
                    %ksp_PC=ksp_PC(:,:,:,30:30,fram_id);
                    sqzSize=size(ksp_PC);
                    %%%%%% ccb
                    
                else
                    ksp_PC=ksp_PC0;
                end
            end
            sqzDims=twix_obj.image.sqzDims;
            IndexCell=cell(size(sqzSize));
            optionsLogical=isfield(options,sqzDims);
            for m=1:length(sqzSize)
                if optionsLogical(m)
                    IndexCell{m}=getfield(options,sqzDims{m});
                else
                    IndexCell{m}=':';
                end
            end
            IndexCell{3}=[2 3];
            ksp_PC=reshape(ksp_PC,sqzSize);
        end
        disp('Phase correction data loaded!');
        %%
        % Phase correction for raw data
        PEacqIndex=unique(twix_obj.image.Lin,'stable');
        IndexCell=cell(1,length(size(ksp)));
        IndexCell(:)={':'};
        IndexCell{3}=PEacqIndex;
        
        if Neco>0
            ksp(IndexCell{:})=EPIEvenoddFix2_oled_e(ksp(IndexCell{:}),ksp_PC,1,3,Neco,-1*snav,false);
        else
            ksp(IndexCell{:})=EPIEvenoddFix_nono(ksp(IndexCell{:}),ksp_PC,1,3,1,snav);
        end
        disp('Phase correction for raw data finished!');
        %%
        % load ACS data
        if (isfield(twix_obj,'refscan') && isfield(twix_obj,'refscanPC'))
            sqz_kCalib=squeeze(twix_obj.refscan());
            sqzSize=twix_obj.refscan.sqzSize;
            sqzDims=twix_obj.refscan.sqzDims;
            
            %%%%%%%%%%%%ccb
            sqz_kCalib=sqz_kCalib(:,:,:,begin_slice:end_slice,:);
            sqzSize=size(sqz_kCalib);
            %%%%%%%%%% ccb
            
            IndexCell=cell(size(sqzSize));
            optionsLogical=isfield(options,sqzDims);
            for m=1:length(sqzSize)
                if optionsLogical(m)
                    IndexCell{m}=getfield(options,sqzDims{m});
                else
                    IndexCell{m}=':';
                end
            end
            kCalib=sqz_kCalib(IndexCell{:});
            
            disp('ACS data loaded!');
            
            %%
            kraw1=permute(kCalib,[1,3,2]);
            %             ksp1=permute(ksp,[1,3,2]);
            kCalib_correct=zeros(size(kraw1));
            %             ksp_correct=zeros(size(ksp1));
            for loopi = 1:size(kraw1,3)
                startOptSimplex.kCenter = 0.35;%0.29
                startOptSimplex.pCenter = 3;%3
                method = 'Gh/Ob';
                [kappa1, phi1] = simplexSearch(kraw1(:,:,loopi), startOptSimplex, method);
                tempK = applyFirstOrderPhaseCorr( kraw1(:,:,loopi), kappa1, phi1);
                kCalib_correct(:,:,loopi) = tempK(:,1:end);
                %                 tempksp = ksp1(:,:,loopi);
                %                 tempksp1 = applyFirstOrderPhaseCorr_raw( tempksp(:,2:2:end), kappa1, phi1);
                %                 ksp_correct(:,2:2:end,loopi) = tempksp1(:,1:end-1);
            end
            kCalib=permute(kCalib_correct,[1,3,2]);
            %             ksp=permute(ksp_correct,[1,3,2]);
            %             if Neco>0
            %                 kCalib=EPIEvenoddFix2_oled_e(kCalib,kCalib_PC,1,3,Neco,1*snav,false);
            %             else
            %                 kCalib=EPIEvenoddFix_nono(kCalib,kCalib_PC,1,3,1,snav);
            %             end
            disp('Phase correction for ACS data finished!');
            
            
            %%
            disp('Performing GCC and GRAPPA for phase difference......');
            if (Nave==1)
                kspSize=size(ksp);
                repmatSize=kspSize;
                repmatSize(1:length(size(kCalib)))=1;
                kCalib=repmat(kCalib,repmatSize);
            else
                ksp=permute(ksp,[1 2 3 5 4]);
                kspSize=size(ksp);
                repmatSize=kspSize;
                repmatSize(1:length(size(kCalib)))=1;
                kCalib=repmat(kCalib,repmatSize);
            end
            permuteorder=[1 3 2 4 5];
            ksp=permute(ksp(:,:,:,:,:),permuteorder);              %[kx,ky,c,array]
            kCalib=permute(kCalib(:,:,:,:,:),permuteorder);
            dim=1;
            ncc=options.gcc.ncc;
            slwin=options.gcc.slwin;
            
            if pec==1
                ksp1=zeros(size(ksp));
                ksp2=zeros(size(ksp));
                for phase_id=2:4:phase_num
                    ksp1(:,phase_id,:,:,:)=ksp(:,phase_id,:,:,:);
                end
                for phase_id=4:4:phase_num
                    ksp2(:,phase_id,:,:,:)=ksp(:,phase_id,:,:,:);
                end
                ksp_gcc1=zeros(size(ksp));
                ksp_gcc2=zeros(size(ksp));
                
                for m=1:echo_train_num  %  m is echo train id
                    ksp_gcc1(:,:,:,1,m)= GRAPPA(ksp1(:,:,:,1,m),kCalib(:,:,:,1,m), [5 5], 0.01);
                    disp(['Odd lines of Echo chain ',num2str(m),' finished!']);
                end
                
                for m=1:echo_train_num  %  m is echo train id
                    ksp_gcc2(:,:,:,1,m)= GRAPPA(ksp2(:,:,:,1,m),kCalib(:,:,:,1,m), [5 5], 0.01);
                    disp(['Even lines of Echo chain ',num2str(m),' finished!']);
                end
                disp('GRAPPA on Odd and Even data finished!');
                ksp_correct=ksp_gcc1+ksp_gcc2;
                ksp_correct(:,1:2:end,:)=0;
            else
                ksp_correct=ksp;
            end
            
            if gcc==1
                disp('Performing GCC and GRAPPA for raw data......');
                ksp_gcc=zeros(freq_num,phase_num,12);
                for slice_id=1:1:slice_num
                    for m=1:para_train_num  %  m is echo train id
                        gccmtx = calcGCCMtx(kCalib(:,:,:,slice_id,m),dim,slwin);
                        gccmtx_aligned = alignCCMtx(gccmtx(:,1:ncc,:),ncc);
                        kCalib_tmp = CC(kCalib(:,:,:,slice_id,m),gccmtx_aligned,dim);
                        ksp_tmp = CC(ksp_correct(:,:,:,slice_id,m),gccmtx_aligned,dim);
                        ksp_gcc(:,:,:,slice_id,m)= GRAPPA(ksp_tmp,kCalib_tmp, [5 5], 0.01);
                    end
                end
                
                ksp_gcc=ipermute(ksp_gcc,permuteorder);
                kspSize(2)=ncc;
                ksp=reshape(ksp_gcc,kspSize);
                ksp=permute(ksp,[1,3,2,5,4]);
                com_data=zeros(freq_num,phase_num,para_train_num);
                for i=1:para_train_num
                    [com_data(:,:,i), gccmtx_aligned_final, Energyx]=CoilCompression(ksp(:,:,:,i),1);
                end
                complex_k2=com_data;
                disp('GRAPPA done');
                disp('GCC and GRAPPA done');
            elseif gcc==2
                disp('Performing GRAPPA for raw data......');
                ksp_gcc=zeros(freq_num,phase_num,channel_num);
                for slice_id=1:1:slice_num
                    for m=1:para_train_num  %  m is echo train id
                        ksp_gcc(:,:,:,slice_id,m)= GRAPPA(ksp_correct(:,:,:,slice_id,m),kCalib(:,:,:,slice_id,m), [5 5], 0.01);
                    end
                end
                com_data=zeros(freq_num,phase_num,para_train_num);
                for i=1:para_train_num
                    [com_data(:,:,i), gccmtx_aligned_final, Energyx]=CoilCompression(ksp_gcc(:,:,:,i),1);
                end
                %ksp=permute(ksp,[3,1,2,4]);
                complex_k2=com_data;
                disp('GRAPPA done');
            else
                disp('Performing GRAPPA for raw data with adaptive coil combination......');
                ksp_gcc=zeros(freq_num,phase_num,channel_num);
                for slice_id=1:1:slice_num
                    for m=1:para_train_num  %  m is echo train id
                        ksp_gcc(:,:,:,slice_id,m)= GRAPPA(ksp_correct(:,:,:,slice_id,m),kCalib(:,:,:,slice_id,m), [5 5], 0.01);
                    end
                end
                com_data=zeros(freq_num,phase_num,para_train_num);
                for i=1:para_train_num
                    [com_data(:,:,i),sen] = adaptive_cmb_2d(ifft2c(ksp_gcc(:,:,:,i)),[1.72,1.72],1,12);
                end
                %ksp=permute(ksp,[3,1,2,4]);
                complex_k2=fft2c(com_data);
                disp('GRAPPA done');
            end
        end
        
        %%
        
        if jjj<10
            tar_file = [output_slice_dir,'Brain_1302_30_layer',num2str(iii),'_fra_00',num2str(jjj),'.mat'];
        elseif jjj<100
            tar_file = [output_slice_dir,'Brain_1302_30_layer',num2str(iii),'_fra_0',num2str(jjj),'.mat'];
        else
            tar_file = [output_slice_dir,'Brain_1302_30_layer',num2str(iii),'_fra_',num2str(jjj),'.mat'];
        end
        save(tar_file,'complex_k2');
        disp(iii);
    end
    recon_order=recon_order+1;
end