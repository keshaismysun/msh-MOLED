function img_cmb = adaptive_combination(img,sen)
[np,nv,nrcvrs] = size(img);
sen = reshape(sen,[],nrcvrs);
img = reshape(img,[],nrcvrs);
img_cmb = sum(conj(sen).*img,2)./sum(sen.*conj(sen),2);
img_cmb = reshape(img_cmb,[np,nv]);
img_cmb(isnan(img_cmb)) = 0;
img_cmb(isinf(img_cmb)) = 0;
end
