function kout=EPIPhaseCorrect(kraw,kpc,ROdim,PEdim,dir,allcoil)

krawsize=size(kraw); %[128,20,24]
krawindex=cell(1,length(krawsize));
krawindex(:)={':'};

kraw_evenindex=krawindex;
kraw_evenindex(PEdim)={2:2:krawsize(PEdim)};

im_1=fftk2r(kpc(:,:,1),[],ROdim);
im_2=fftk2r(kpc(:,:,2),[],ROdim);
im_3=fftk2r(kpc(:,:,3),[],ROdim);

im_2fit=im_1.*exp(1i*angle(conj(im_1).*im_3)/2);
pherror=angle(conj(im_2fit).*im_2);

fitx=[krawsize(1)/2-24:krawsize(1)/2+24];
mx=1:krawsize(1);

pfit=zeros(krawsize(2),2);
cphase=zeros(krawsize(1),krawsize(2));

for coiln=1:krawsize(2)
    temp            = pherror(:,coiln)';
    pfit(coiln,:)   = polyfit(fitx,temp(fitx),1);
    cphase(:,coiln) = polyval(pfit(coiln,:),mx)';
end

if allcoil == 1
    ph            = mean(exp(dir*-1i*cphase),2);
    repmatsize    = ones(1,length(krawsize));
    repmatsize(PEdim) = length(kraw_evenindex{PEdim});
    repmatsize(2) = krawsize(2);
    ph            = repmat(ph,repmatsize);
else
    ph         = exp(dir*-1i*cphase);
    repmatsize = ones(1,length(krawsize));
    repmatsize(PEdim) = length(kraw_evenindex{PEdim});
    ph         = repmat(ph,repmatsize);
end

im=fftk2r(kraw,[],ROdim);
im(kraw_evenindex{:})=im(kraw_evenindex{:}).*ph;
kout=fftr2k(im,[],ROdim);
