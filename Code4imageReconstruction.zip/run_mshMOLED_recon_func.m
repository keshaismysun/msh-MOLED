function ksp_cor = run_mshMOLED_recon_func(ksp_raw, ksp_PC, Nread, Ncoil, NETL, Nseg, Necho, snav)
    ksp_tmp = permute(ksp_raw, [1 3 2]);
    ksp_cor = zeros(Nread, Ncoil, NETL.*Nseg);
    ksp_PC  = permute(ksp_PC , [1 3 2]);
    ksp_seg = zeros(Nread, Ncoil, NETL, Nseg);


    for id_seg = 1:Nseg
        ksp_seg(:,:,:,id_seg)          = ksp_tmp(:,:,id_seg:Nseg:end);
        ksp_cor(:,:,id_seg:Nseg:end,:) = EPIEvenoddFix2_msholed(ksp_seg(:,:,:,id_seg),ksp_PC,1,3,Necho,snav,true);
    end
    ksp_cor = permute(ksp_cor, [1 3 2 4]);
    disp('eddy current corrected.')
end