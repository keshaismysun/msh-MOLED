function kout = EPIEvenoddFix2_msholed(kraw,kpc,ROdim,PEdim,Neco,snav,is_same_train)
%kraw data need to be corrected
% kpc navigator
% ROdim dim number of RO
% PEdim dim number of PE
% Neco number of echoes
%snav  sign of phase 

channel_num = size(kraw,2);
slice_num   = size(kraw,4);

krawsize     = size(kraw);
krawindex    = cell(1,length(krawsize));
krawindex(:) = {':'};

kraw_evenindex = krawindex;
kpc_oddindex   = krawindex;
kpc_eveindex   = krawindex;

kraw_evenindex(PEdim) = {2:2:krawsize(PEdim)};

if(snav == 1)
    kpc_oddindex(PEdim) = {1};
    kpc_eveindex(PEdim) = {2};
else
    kpc_oddindex(PEdim) = {2};
    kpc_eveindex(PEdim) = {1};
end

im_odd  = fftk2r(kpc(kpc_oddindex{:}),[],ROdim);
im_even = fftk2r(kpc(kpc_eveindex{:}),[],ROdim);
mask    = ones(size(im_odd));

for channel_id = 1:1:channel_num
    mask(:,channel_id,:) = GetMagBasedMask(abs(im_odd(:,channel_id,:)), abs(im_even(:,channel_id,:)),2);  % maybe 10 for brain
    fx = mask(:,channel_id,:).*angle(conj(im_even(:,channel_id,:)).*im_odd(:,channel_id,:));  % 37 channel has some fit problem
    for freq_pos = 1:1:size(fx,1)
        if fx(freq_pos) > pi 
            fx(freq_pos) = fx(freq_pos)-2*pi ;
        else 
            if fx(freq_pos) < -pi
                fx(freq_pos) = fx(freq_pos)+2*pi;
            end
        end
    end
    x      = (1:size(kraw,1))';
    mx     = find(mask(:,channel_id,:)~=0);
    pfit   = polyfit(mx,fx(mx),1);
    cphase = polyval(pfit,x);
    if is_same_train == true 
        ph(:,channel_id,:)=exp(1i*cphase);
    else
        if mod(Neco,2)== 1
            ph(:,channel_id,:)=exp(1i*cphase);
        else
            ph(:,channel_id,:)=exp(-1i*cphase);
        end
    end
end  

mean_value_team = reshape(mean(abs(im_odd)+abs(im_even)),1,channel_num,1,slice_num,Neco);
max_value_team  = max(mean_value_team,[],2);

channel_mask_team = zeros(size(mean_value_team));
for channel_id = 1:1:channel_num
    for slice_id = 1:1:slice_num
        channel_mask_team(1,channel_id,1,slice_id,:) = mean_value_team(1,channel_id,1,slice_id,:)>max_value_team(1,1,1,slice_id,:)/10;
    end
end

%mask_num_team=zeros(1,channel_num,1,slice_num,Neco);
mask_num_team=sum(mask,1);

 channel_mask_team=channel_mask_team.*(mask_num_team>size(ph,1)/2);
% channel_mask_team=channel_mask_team.*(mask_num_team>size(ph,1)/2*220/307); % qzyang for FOV = 307

channel_add_num=sum(channel_mask_team, 2);

ph_aver=zeros(size(ph,1),1,size(ph,3),size(ph,4),size(ph,5));

for freq_pos=1:1:size(ph,1)
    for slice_id=1:1:slice_num
        for train_id=1:1:Neco
            ph_aver(freq_pos,1,1,slice_id,:)=sum(angle(ph(freq_pos,:,1,slice_id,:).*channel_mask_team(1,:,1,slice_id,:)),2)./channel_add_num(1,1,1,slice_id,:);
        end
    end
end

% ph_aver=sum(angle(ph),2)/channel_num;


for channel_id= 1:1:channel_num
    ph(:,channel_id,:,:,:)=exp(1i*ph_aver(:,1,:,:,:));
end


im=fftk2r(kraw,[],ROdim);
im(kraw_evenindex{:})=im(kraw_evenindex{:}).*ph;
kout=fftr2k(im,[],ROdim);


