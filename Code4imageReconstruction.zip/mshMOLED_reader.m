function [ksp_raw, ksp_PC, Nread, Nphase, Nslice, Ncoil, NETL, Nseg, FOVread, FOVphase] = mshMOLED_reader(datafile)

twix_obj   = mapVBVD(datafile,'removeOS','ignoreSeg','rampSampRegrid');
if iscell(twix_obj)
    twix_obj = twix_obj{end};
end
ksp_raw = squeeze(twix_obj.image());
ksp_raw = permute(ksp_raw,[1 3 2 4]);
disp('Raw msh-MOLED data loaded!');

% scan parameters
Nread  = twix_obj.hdr.Dicom.lBaseResolution;
Nphase = twix_obj.image.NLin;
Nslice = twix_obj.image.NSli;
Ncoil  = twix_obj.image.NCha;
NETL   = twix_obj.hdr.Dicom.EchoTrainLength;
Nseg   = Nphase/NETL;
FOVread  = twix_obj.hdr.Config.ReadFoV;
FOVphase = twix_obj.hdr.Config.PhaseFoV;

% phase correction data
if (isfield(twix_obj,'phasecor'))
    ksp_PC0 = squeeze(twix_obj.phasecor.unsorted());
    Neco    = twix_obj.image.NEco;
    ksp_PC0 = reshape(ksp_PC0,[Nread, Ncoil, 3, Nslice]); % 3 - the navigator
    if eq(Neco, 1) % qzyang For multi-echo-train
        ksp_PC  = ksp_PC0;
        ksp_PC = permute(ksp_PC,[1 3 2 4]); % RO PE coil slice
    else
        ksp_PC = zeros([size(ksp_PC0) Neco]);
        for neco = 1:Neco
            ksp_PC(:,:,:,:,neco) = ksp_PC0;
        end
    end
end
disp('Phase correction data loaded!');

% reorder
if eq(mod(Nslice,2),1)
    index_slice = 1:(Nslice+1);
else
    index_slice = 1:Nslice;
end
index_slice   = reshape(index_slice, [], 2);
index_slice   = index_slice';
index_nominal = index_slice(:);
index_nominal = index_nominal(1:Nslice);
ksp_raw = ksp_raw(:,:,:,index_nominal);
ksp_PC  = ksp_PC (:,:,:,index_nominal);